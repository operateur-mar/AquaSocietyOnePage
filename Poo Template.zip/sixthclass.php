<section class="sixthsection">

    <!-- section Title -->
    <h1 class="text-center sectiontitle">معك دائما على مواقع التواصل الإجتماعي</h1>
    <hr class="style14">
    <h4 class="text-center sectiondescription container">إن كنت مهتما بالتعرف علينا أكثر ، و تريد الإنضمام الى صفحاتنا على مواقع التواصل
        فنرحب بك ، في صفحاتنا ، سنقدم لك يوميا معلومات مفيدة حتى قبل إطلاق الموقع ، كما نستقبل من خلالها أيضا أي إقتراحات ، طلبات الإنضمام الى فريق العمل
        و أيضا طلبات الخدمات القبلية للتنفيذ ، نرحب بكم :
    </h4>
    <!-- ./Section -->


    <!-- Social Media Class -->
    <div class="text-center">
        <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fpg%2FAqua-Scoiety-%25D8%25A3%25D9%2583%25D9%2588%25D8%25A7-%25D8%25B3%25D9%2588%25D8%25B3%25D8%25A7%25D9%258A%25D8%25AA%25D9%258A-1457400864328317%2Fabout%2F%3Fref%3Dpage_internal&tabs&width=340&height=70&small_header=true&adapt_container_width=true&hide_cover=true&show_facepile=false&appId=479702552145140" width="340" height="70" style="margin: 15px;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
    </div>
    <div class="social_media">
        <h1><a href="https://www.facebook.com/AquaWeb.Society/?ref=bookmarks"><i class="fa fa-facebook-square"></i></a></h1>
        <h1><a href="https://www.pinterest.com/aquaweeb/"><i class="fa fa-pinterest-square"></i></a></h1>
        <h1><a href="https://twitter.com/aqua_weeb"><i class="fa fa-twitter-square"></i></a></h1>
        <h1><a href="https://plus.google.com/u/0/+RidaDahhaneOPS"><i class="fa fa-google-plus-square"></i></a></h1>
        <h1><a href="https://www.instagram.com/aqua.web/"><i class="fa fa-instagram"></i></a></h1>
        <h1><a href="https://www.youtube.com/channel/UCnBtRFIUIuDMRqGppt8aqzw"><i class="fa fa-youtube-square"></i></a></h1>



    </div>



    <!-- .Social -->
</section>