<section class="secondsection">

    <!-- section Title -->
    <h1 class="text-center sectiontitle">سنطلق الموقع بعد :  </h1>
    <!-- ./Section -->


    <!-- Timer -->
    <p id="timer" class="text-center timer"></p>

    <!-- ./ Timer -->
</section>