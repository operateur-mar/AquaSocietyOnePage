

<div class="text-center the-footer" >
    &copy; Aqua Sciety 2017 | جميع الحقوق محفوظة ل مجتمع أكوا
</div>

        <?php wp_footer(); ?>
    </body>
</html>
