<section class="firstsection " id="firstclass">

    <!-- section Title -->
    <h1 class="text-center sectiontitle">توصل بجديدنا فور إطلاق الموقع رسميا</h1>
    <hr class="style14">
    <h4 class="text-center sectiondescription container"> ستود حقا ان تنضم إلينا صديقي في رحلتنا لإطلاق الموقع ، ببساطة ، أدخل بريدك الإلكتروني و تسجل و سنقوم بإشعارك في البريد أثناء إطلاق الموقع بشكل رسمي
    </h4>
    <!-- ./Section -->
            <div class="container">
                <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                                    <input class="effect-3 email-subscribtion-input" type="email" placeholder="أدخل البريد الإلكتروني هنا" name="EMAIL" required >
                                    <span class="focus-border"></span>
                        </div>
                        <div class="col-md-4"></div>

                </div>
                <main id="st-main">
                    <button class="material-button" type="submit">توصل بجديدنا</button>
                </main>
            </div>
</section>

