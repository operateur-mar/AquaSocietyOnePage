<?php get_header(); ?>

<?php include 'firstclass.php' ?>
<?php include 'secondclass.php' ?>
<?php include 'thirdclass.php' ?>
<?php include 'eighthclass.php' ?>
<?php include 'sixthclass.php' ?>







<?php get_footer(); ?>
